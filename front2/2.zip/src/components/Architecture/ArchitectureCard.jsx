import StatCard from "../Overview/StatCard.jsx";
import MermaidDiagram from "./MermaidDiagram.jsx";
import "./ArchitectureCard.css";

/**
 * Regroupe les informations d'architecture : nom détecté, confiance,
 * score, explication textuelle, et le diagramme Mermaid s'il existe.
 */
function ArchitectureCard({ name, confidence, score, explanation, diagramCode }) {
  return (
    <div className="architecture-card">
      <div className="stat-grid stat-grid-compact">
        <StatCard label="Architecture" value={name} tone="brand" />
        <StatCard label="Confidence" value={confidence !== null ? `${confidence}%` : "-"} />
        <StatCard label="Score" value={score ?? "-"} />
      </div>

      <p className="architecture-explanation">{explanation}</p>

      <MermaidDiagram code={diagramCode} />
    </div>
  );
}

export default ArchitectureCard;
