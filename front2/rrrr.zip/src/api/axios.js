import axios from "axios";

// 1. توحيد الـ Host مع الـ Frontend (استعمال localhost دائماً لمنع مشاكل الـ CORS)
const DEFAULT_URL = "http://localhost:5000/api";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || DEFAULT_URL,
  headers: {
    "Content-Type": "application/json",
  },
  // 300,000 ms = 5 دقائق بالضبط (5 * 60 * 1000)
  timeout: 300000,
});

// Injecte automatiquement le token d'authentification si présent
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Gestion centralisée des erreurs
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export default api;