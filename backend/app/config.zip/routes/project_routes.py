from flask import Blueprint, request, jsonify
from app.extensions import db
from app.models.project import Project

project_bp = Blueprint("projects", __name__)


# GET ALL PROJECTS
@project_bp.route("", methods=["GET"])
def get_projects():
    projects = Project.query.all()
    # Nsta3mlou to_dict() direct bech t-koun ndhifa
    return jsonify([p.to_dict() for p in projects]), 200


# CREATE PROJECT
@project_bp.route("", methods=["POST"])
def create_project():
    data = request.get_json() or {}

    if "user_id" not in data or "name" not in data or "github_url" not in data:
        return jsonify({"error": "user_id, name et github_url sont obligatoires"}), 400

    project = Project(
        user_id=data["user_id"],
        name=data["name"],
        github_url=data["github_url"],
        description=data.get("description"),
        language=data.get("language")
        # Na77ina el status hna khater tna99al lel analyses table
    )

    db.session.add(project)
    db.session.commit()

    return jsonify({
        "message": "Project created",
        "project": project.to_dict()
    }), 201


# UPDATE PROJECT
@project_bp.route("/<int:id>", methods=["PUT"])
def update_project(id):
    project = Project.query.get_or_404(id)
    data = request.get_json() or {}

    project.name = data.get("name", project.name)
    project.github_url = data.get("github_url", project.github_url)
    project.description = data.get("description", project.description)
    project.language = data.get("language", project.language)
    # Na77ina line project.status hna zeda

    db.session.commit()

    return jsonify({
        "message": "Project updated",
        "project": project.to_dict()
    }), 200


# DELETE PROJECT
@project_bp.route("/<int:id>", methods=["DELETE"])
def delete_project(id):
    project = Project.query.get_or_404(id)

    db.session.delete(project)
    db.session.commit()

    return jsonify({
        "message": "Project deleted"
    }), 200