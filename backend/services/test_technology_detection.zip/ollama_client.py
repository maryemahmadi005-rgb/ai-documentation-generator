"""
ollama_client.py

Client Ollama local.
Avec fallback heuristique si Ollama indisponible.

Optimisations de performance :
- instance CLIENT PARTAGÉE (singleton) : le test de disponibilité
  (is_available) n'est plus refait à chaque fichier, mais une seule
  fois par run.
- circuit breaker : après plusieurs échecs/timeouts consécutifs,
  on arrête d'appeler Ollama pour le reste de l'analyse et on
  bascule automatiquement sur le résumé heuristique.
- timeout par génération réduit et configurable (au lieu de 60s
  fixes, multipliés par le nombre de fichiers).
"""

import json
import os
import re
import threading
import requests

from urllib.parse import urlparse
from typing import Optional


OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434/api/generate")
DEFAULT_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.2:3b")

# Timeout par appel de génération. Volontairement réduit par rapport à
# l'ancien timeout de 60s : sur un repo de plusieurs centaines de
# fichiers, un timeout élevé multiplié par le nombre de fichiers est
# l'une des causes principales des temps d'analyse très longs.
GENERATE_TIMEOUT = int(os.environ.get("OLLAMA_GENERATE_TIMEOUT", "60"))
AVAILABILITY_TIMEOUT = 2

# Timeout spécifique à l'analyse globale du projet (prompt plus long,
# une seule fois par run donc on peut se permettre plus de marge que
# pour un résumé de fichier individuel).
PROJECT_ANALYSIS_TIMEOUT = int(
    os.environ.get("OLLAMA_PROJECT_ANALYSIS_TIMEOUT", "180")
)

# Circuit breaker : après N échecs/timeouts consécutifs, on considère
# qu'Ollama est indisponible ou trop lent, et on bascule
# automatiquement et définitivement (pour ce run) sur le fallback
# heuristique, sans retenter d'appel réseau à chaque fichier.
MAX_CONSECUTIVE_FAILURES = int(os.environ.get("OLLAMA_MAX_FAILURES", "3"))

DEFAULT_MAX_CHARS = 1500
SYSTEM_RULES = """
Tu es un expert en analyse de dépôts logiciels.

Règles obligatoires :
- Utilise uniquement les informations fournies.
- Ne suppose jamais une fonctionnalité.
- Ne transforme pas un nom de fichier en preuve de fonctionnalité.
- Si une information manque, indique "Non déterminé".
- Priorité aux preuves du code source.
- Sépare toujours les faits observés des interprétations.
"""


class OllamaClient:

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        url: str = OLLAMA_URL,
        timeout: int = GENERATE_TIMEOUT
    ):

        self.model = model
        self.url = url
        self.timeout = timeout

        parsed = urlparse(url)
        self.base_url = f"{parsed.scheme}://{parsed.netloc}"

        self.available_cache = None
        self.consecutive_failures = 0
        self.circuit_open = False

        self._lock = threading.Lock()

    # ======================================================
    # Check Ollama
    # ======================================================

    def is_available(self):

        if self.circuit_open:
            return False

        if self.available_cache is not None:
            return self.available_cache

        try:
            response = requests.get(
                self.base_url,
                timeout=AVAILABILITY_TIMEOUT
            )
            self.available_cache = response.status_code == 200

        except requests.exceptions.RequestException:
            self.available_cache = False

        return self.available_cache

    # ======================================================
    # Circuit breaker helpers
    # ======================================================

    def _register_failure(self):
        with self._lock:
            self.consecutive_failures += 1
            if self.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                self.circuit_open = True

    def _register_success(self):
        with self._lock:
            self.consecutive_failures = 0

    # ======================================================
    # Generate
    # ======================================================

    def generate(
        self,
        prompt: str,
        system: str = "",
        timeout: Optional[int] = None
    ) -> Optional[str]:

        if not self.is_available():
            return None

        payload = {
            "model": self.model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "options": {
                "temperature": 0.1
            }
        }

        try:
            response = requests.post(
                self.url,
                json=payload,
                timeout=timeout if timeout is not None else self.timeout
            )
            response.raise_for_status()
            print("OLLAMA RAW RESPONSE:")
            print(response.text)

            data = response.json()
            print("OLLAMA JSON:")
            print(data)
            self._register_success()
            return data.get("response", "").strip()
        except requests.exceptions.Timeout as exc:
            print("OLLAMA TIMEOUT:", repr(exc))
            self._register_failure()
            return None
        except requests.exceptions.ConnectionError as exc:
            print("OLLAMA CONNECTION ERROR:", repr(exc))
            self._register_failure()
            return None
        except Exception as exc:
            print("OLLAMA ERROR:", repr(exc))
            self._register_failure()
            return None

    def _fallback_readme_content(
        self,
        project_name,
        tech_stack,
        dependencies=None,
        entry_points=None,
        key_files_digest=None,
        structure_overview=None
    ):
        return _fallback_readme_content(
            project_name,
            tech_stack, 
            dependencies,
            entry_points,
            key_files_digest,
            structure_overview,
            )

    def _fallback_technical_documentation_content(
        self,
        project_name,
        tech_stack,
        databases,
        architecture_type,
        architecture_confidence,
        structure_overview,
        entry_points=None,
        dependencies=None,
    ):
        return _fallback_technical_documentation_content(
            project_name,
            tech_stack,
            databases,
            architecture_type,
            architecture_confidence,
            structure_overview,
            entry_points,
            dependencies,
        )

    # ======================================================
    # Summarize file
    # ======================================================

    def summarize_file(
        self,
        filepath,
        content,
        max_chars=DEFAULT_MAX_CHARS
    ):

        snippet = content[:max_chars]

        prompt = f"""
Fichier : {filepath}

Tu es un ingénieur logiciel senior spécialisé en documentation technique.

Analyse uniquement le fichier fourni.

Fichier :
{filepath}

Code source :
{snippet}

RÈGLES STRICTES :
- Ne crée aucune information absente du code.
- Ne suppose pas le comportement métier.
- Ne mentionne que les classes, fonctions et imports visibles.
- Si une information manque, écris "Aucune information disponible".

Génère une documentation Markdown :

## Résumé
Explique le rôle exact du fichier.

## Responsabilité
Explique sa place dans le projet.

## Classes et fonctions
Liste uniquement les éléments détectés.

## Imports et dépendances
Liste les dépendances visibles.

## Points importants
Mentionne uniquement les éléments présents dans le code.

Ne copie pas le code.
"""

        try:
            result = self.generate(
                prompt,
                system=SYSTEM_RULES            )
        except Exception as exc:
            print("OLLAMA FILE SUMMARY ERROR:", repr(exc))
            self._register_failure()
            result = None

        if result:
            return result

        return heuristic_summary(filepath, content)

    # ======================================================
    # Analyze project (analyse globale, pas fichier par fichier)
    # ======================================================

    def generate_readme_content(
        self,
        project_name,
        tech_stack,
        dependencies=None,
        entry_points=None,
        existing_readme_excerpt=None,
        key_files_digest=None,
        code_inventory=None,
        structure_overview=None,
        databases=None,
    ) -> str:
        tech_text = ", ".join(tech_stack) if tech_stack else "Non déterminées"
        databases_text = ", ".join(databases) if databases else "Non détectées"
        structure_text = (
            structure_overview 
            if structure_overview 
            else "Structure non disponible."
        )
        dependency_text = "\n".join(f"- {dep}" for dep in (dependencies or [])[:8]) if dependencies else "- Aucune dépendance majeure détectée."
        entry_points_text = "\n".join(f"- {ep}" for ep in (entry_points or [])[:4]) if entry_points else "- Aucun point d'entrée explicite détecté."
        readme_block = (
            f"\nREADME d'origine (extrait) :\n\"\"\"\n{existing_readme_excerpt}\n\"\"\"\n"
            if existing_readme_excerpt
            else ""
        )
        digest_text = (
            "\n".join(key_files_digest)
            if key_files_digest
            else "Aucun fichier important identifié."
            )
        code_inventory_text = (
            code_inventory
            if code_inventory
            else "Aucun détail de code disponible."
            )
        
        prompt = f"""
        Tu es un ingénieur logiciel senior spécialisé dans la rédaction de README.md professionnels.
        MODE D'ANALYSE FACTUEL :
        Avant d'écrire chaque information, vérifie qu'elle existe dans les données fournies.
        Règles :
        - Utilise uniquement les preuves présentes dans le repository.
        - Ne déduis jamais une fonctionnalité depuis un nom de fichier.
        - Ne transforme pas une technologie détectée en fonctionnalité.
        - Si une information n'est pas prouvée : écris "Non déterminé".
        Ta mission est de lire et comprendre un projet logiciel réel à partir des informations
        fournies ci-dessous, puis de générer un README.md spécifique à ce projet.

IMPORTANT :
- Décris le projet lui-même, pas le processus d'analyse.
SOURCE PRIORITY :
Utilise les informations dans cet ordre :

1. Structure réelle du repository
2. Fichiers importants détectés
3. Imports et dépendances
4. Points d'entrée
5. README original comme contexte uniquement

Si deux informations sont contradictoires,
privilégie les informations extraites du code.
- Le README doit être utile pour un développeur qui découvre ce repository.
- Utilise uniquement les informations fournies.
- Ne fais aucune supposition non vérifiée.
- Ne génère pas de contenu générique applicable à n'importe quel projet.

Nom du projet :
{project_name}

Technologies utilisées :
{tech_text}

Bases de données détectées :
{databases_text}

Dépendances principales :
{dependency_text}

Points d'entrée :
{entry_points_text}

Structure du projet :
{structure_text}

Fichiers importants et leur rôle :
{digest_text}

Inventaire du code :
{code_inventory_text}

README original du projet (utilise-le uniquement pour comprendre l'objectif,
ne le copie jamais directement) :
{readme_block}


RÈGLES STRICTES :
Ne mentionne jamais dans le README :
- l'analyse automatique
- la génération par IA
- le pipeline d'analyse
- le nombre de fichiers analysés
- le score d'analyse
- le pourcentage de confiance
- l'architecture détectée par l'outil
- les résultats de classification automatique


Génère un README Markdown professionnel avec exactement ces sections :


# {project_name}

## Description

Décris uniquement l'objectif démontré par :
- README original
- fichiers d'entrée
- fonctions principales
- imports
- structure du projet

Si aucune preuve n'existe :
"Aucune information disponible"


## Fonctionnalités principales

Liste uniquement les fonctionnalités réellement présentes dans le projet.
Utilise les informations provenant du code et des fichiers importants.


## Technologies utilisées

Présente :
- langages utilisés
- frameworks
- bibliothèques principales
- outils nécessaires


## Installation

Explique comment installer le projet.

Si les informations sont disponibles :
- commandes d'installation
- dépendances nécessaires
- configuration requise

Ne crée pas de commandes inexistantes.


## Utilisation

Explique comment démarrer ou utiliser le projet.

Utilise uniquement les points d'entrée et informations disponibles.


## Structure du projet

Présente une structure simplifiée du repository.

Pour chaque dossier important explique son rôle.

Ne liste pas tous les fichiers automatiquement.


## Modules importants

Décris les fichiers ou modules principaux :
- leur responsabilité
- leur rôle dans le fonctionnement du projet


## Informations de développement

Ajoute :
- prérequis
- dépendances importantes
- informations utiles pour contribuer au projet


FORMAT :
- Réponds uniquement avec le contenu Markdown du README.
- N'ajoute aucune explication avant ou après.
- Utilise un style professionnel et clair.
- Écris en français.
"""

        try:
            result = self.generate(
                prompt,
                system="Tu es un assistant spécialisé dans la génération de README concis et orientés présentation.",
                timeout=PROJECT_ANALYSIS_TIMEOUT,
            )
        except Exception as exc:
            print("OLLAMA README ERROR:", repr(exc))
            self._register_failure()
            result = None
        if result:
            print("===== README AI =====")
            print(result[:1000])
            print("====================")
            bad_sections = [
                "Architecture détectée",
                "Analyse détaillée des fichiers",
                "Score d'analyse",
                "Confiance :",

            ]
            if any(section in result for section in bad_sections):
                print("⚠️ README generated as technical documentation, using fallback")
                return _fallback_readme_content(
                     project_name,
                     tech_stack,
                     dependencies=None,
                     entry_points=None,
                     key_files_digest=None,
                     structure_overview=None

                     )
            return result


        return _fallback_readme_content(project_name, tech_stack, dependencies, entry_points)

    def generate_technical_documentation_content(
        self,
        project_name,
        tech_stack,
        databases,
        architecture_type,
        architecture_confidence,
        structure_overview,
        key_files_digest,
        entry_points=None,
        dependencies=None,
        code_inventory="",
        existing_readme_excerpt=None,
        repository_url=None,
        language=None,
    ) -> str:
        tech_text = ", ".join(tech_stack) if tech_stack else "Non déterminées"
        databases_text = ", ".join(databases) if databases else "Non détectées"
        dependency_text = "\n".join(
            f"- {dep}" for dep in (dependencies or [])[:8]
            ) if dependencies else "- Aucune dépendance majeure détectée."
        entry_points_text = "\n".join(
            f"- {ep}" for ep in (entry_points or [])[:4]
            ) if entry_points else "- Aucun point d'entrée explicite détecté."
        structure_text = structure_overview if structure_overview else "Structure non disponible."
        
        code_inventory_text = (
            code_inventory
            if code_inventory
            else "Aucun détail de code disponible."
                )
        digest_text = "\n".join(key_files_digest) if key_files_digest else "Aucun fichier clé identifié."
        entry_points_text = "\n".join(f"- {ep}" for ep in (entry_points or [])[:8]) if entry_points else "- Aucun point d'entrée identifié automatiquement."
        dependencies_text = "\n".join(f"- {dep}" for dep in (dependencies or [])[:12]) if dependencies else "- Aucune dépendance majeure identifiée automatiquement."
        repository_text = repository_url or "Non détecté"
        language_text = language or "Non détecté"

        readme_block = (
            f"\nREADME d'origine (extrait) :\n\"\"\"\n{existing_readme_excerpt}\n\"\"\"\n"
            if existing_readme_excerpt
            else ""
        )

        prompt = f"""
Projet : {project_name}
MODE D'ANALYSE FACTUEL :

- Décris uniquement les éléments visibles dans le repository.
- Ne suppose aucune fonctionnalité métier.
- Ne crée aucune API, base de données ou module absent.
- Sépare les observations des interprétations.

Génère une documentation technique complète et professionnelle basée sur l'analyse du dépôt.
Règles absolues :
- Ne pas reproduire le contenu du README.
- Ne pas se limiter à un résumé superficiel.
- Produire des sections détaillées : Objectif du projet, Fonctionnement général, Architecture détectée, Technologies utilisées, Structure du projet, Modules principaux, Flux de données, Points d'entrée, Dépendances importantes, Analyse détaillée des fichiers et Recommandations.
- Basé uniquement sur les informations ci-dessous.

Technologies détectées : {tech_text}
Repository :{repository_text}
Langage principal :{language_text}
Bases de données détectées : {databases_text}
Signal architectural détecté :
{architecture_type}

Cette information provient d'une détection automatique.
Présente-la comme une observation, pas comme une certitude.
Structure du projet :
Structure du projet :
Structure du projet :
{structure_overview}
Fichiers clés :
{digest_text}
Inventaire du code :
{code_inventory_text}
Points d'entrée :
{entry_points_text}
Dépendances importantes :
{dependencies_text}
{readme_block}
Réponds en français, en Markdown, avec un ton technique et structuré.
"""

        try:
            result = self.generate(
                prompt,
                system="Tu es un architecte logiciel senior chargé de produire une documentation technique détaillée et distincte d'un README.",
                timeout=PROJECT_ANALYSIS_TIMEOUT,
            )
        except Exception as exc:
            print("OLLAMA TECHNICAL DOC ERROR:", repr(exc))
            self._register_failure()
            result = None

        if result:
            return result

        return self._fallback_technical_documentation_content(
            project_name,
            tech_stack,
            databases,
            architecture_type,
            architecture_confidence,
            structure_overview,
            entry_points,
            dependencies,
        )

    def analyze_project(
        self,
        project_name,
        tech_stack,
        databases,
        architecture_type,
        architecture_confidence,
        structure_overview,
        key_files_digest,
        existing_readme_excerpt=None,
        entry_points=None,
        dependencies=None,
        code_inventory="",
        repository_url=None,
        language=None,
        ):
        
        """
        Analyse le projet dans son ensemble (et non fichier par
        fichier) : objectif, fonctionnement général, technologies,
        architecture, modules principaux, flux de données, points
        d'entrée, dépendances importantes, recommandations. C'est ce
        texte qui sert de résumé IA global (`ai_summary`) et d'intro
        du README, à la place d'une simple concaténation de résumés
        de fichiers.
        Important:
        Do not invent databases, APIs or technologies.
        If information is unavailable, say "Non détecté".

        `existing_readme_excerpt` (optionnel) : contenu du README
        d'origine du projet, s'il existe. Donne un vrai ancrage à
        l'IA sur l'objectif réel du projet plutôt que de le déduire
        uniquement de la structure des fichiers.

        `entry_points` / `dependencies` (optionnels) : listes de
        chaînes déjà formatées (ex: "app.py — point d'entrée Flask",
        "flask==3.0.0"), utilisées à la fois par le prompt IA et par
        le fallback heuristique.
        """

        tech_text = ", ".join(tech_stack) if tech_stack else "Non déterminées"
        databases_text = (
            ", ".join(databases)
            if databases
            else "Non détectées"
            )

        digest_text = (
            "\n".join(key_files_digest)
            if key_files_digest
            else "Aucun fichier clé identifié."
        )

        entry_points_text = (
            "\n".join(f"- {ep}" for ep in entry_points)
            if entry_points
            else "Aucun point d'entrée identifié automatiquement."
        )

        dependencies_text = (
            "\n".join(f"- {dep}" for dep in dependencies)
            if dependencies
            else "Aucune dépendance clé identifiée automatiquement."
        )
        code_inventory_text = code_inventory if code_inventory else "Aucun détail de code détecté."

        readme_block = (
            f"""
README d'origine du projet (extrait) :
\"\"\"
{existing_readme_excerpt}
\"\"\"
"""
            if existing_readme_excerpt
            else ""
        )

        prompt = f"""
Projet : {project_name}

IMPORTANT : Utilise UNIQUEMENT les informations explicitement fournies ci-dessous. Ne invente jamais de base de données, d'API, de framework, de technologie ou de module. Si une information n'est pas détectée dans le repository, écris "Non déterminé" ou "Aucune preuve détectée dans le repository".

Technologies détectées : {tech_text}
Bases de données détectées : {databases_text}

Architecture détectée : {architecture_type} (confiance : {architecture_confidence}%)

Structure du projet (aperçu) :
{structure_overview}

Fichiers clés et leur rôle :
{digest_text}
Inventaire du code :
{code_inventory_text}

Points d'entrée détectés :
{entry_points_text}

Dépendances principales détectées :
{dependencies_text}
{readme_block}
Méthode d'analyse :

- Commence par identifier les éléments réellement présents.
- Explique uniquement les relations visibles.
- Ne déduis pas les fonctionnalités depuis les noms des fichiers.
- Ne complète jamais les parties manquantes.
Analyse ce projet dans son ensemble, comme le ferait un·e architecte logiciel·le senior. Ne recopie jamais le README mot pour mot. N'invente pas d'information non présente dans les données fournies.

Réponds en français, en Markdown, avec exactement ces sections (utilise ces titres tels quels, dans cet ordre) :

## Objectif du projet
## Fonctionnement général
## Technologies utilisées
## Bases de données
## Architecture
## Modules principaux
## Flux de données
## Points d'entrée
## Dépendances importantes
## Recommandations
"""

        try:
            result = self.generate(
                prompt,
                system=(
                    "Tu es un architecte logiciel senior chargé de "
                    "documenter un projet pour un onboarding rapide."
                ),
                timeout=PROJECT_ANALYSIS_TIMEOUT
            )
        except Exception as exc:
            print("OLLAMA PROJECT ANALYSIS ERROR:", repr(exc))
            self._register_failure()
            result = None

        if result:
            return result

        return heuristic_project_summary(
            project_name,
            tech_stack,
            databases,
            architecture_type,
            architecture_confidence,
            key_files_digest,
            existing_readme_excerpt=existing_readme_excerpt,
            entry_points=entry_points,
            dependencies=dependencies,
        )


# ==========================================================
# Client partagé (singleton)
# ==========================================================
#
# Avant cette optimisation, generate_summary() créait un nouveau
# OllamaClient() à CHAQUE fichier. Cela forçait un nouveau test de
# disponibilité (requête HTTP, jusqu'à 2s) à chaque fichier, même si
# Ollama était indisponible. Sur un repo de 200 fichiers, cela pouvait
# ajouter à lui seul jusqu'à 200 x 2s = 400s, avant même de tenter une
# seule génération.
#
# Le client partagé ne teste la disponibilité qu'une seule fois par
# run, et porte le circuit breaker pour tout le pipeline.

_default_client_lock = threading.Lock()
_default_client: Optional[OllamaClient] = None


def get_default_client() -> OllamaClient:
    """Retourne l'instance OllamaClient partagée pour ce run."""
    global _default_client
    with _default_client_lock:
        if _default_client is None:
            _default_client = OllamaClient()
        return _default_client


def reset_default_client():
    """
    Réinitialise le client partagé (force un nouveau test de
    disponibilité et remet le circuit breaker à zéro). Utile entre
    deux analyses de repository distinctes, ou pour les tests.
    """
    global _default_client
    with _default_client_lock:
        _default_client = None


# ==========================================================
# Compatibility function
# Utilisée par documentation_service.py
# ==========================================================

def generate_summary(
    content: str,
    filepath: str = "unknown"
):
    """
    Conserve la signature historique (content) tout en acceptant en
    plus un filepath optionnel pour un meilleur résumé heuristique.
    Utilise désormais le client partagé au lieu d'en recréer un
    nouveau à chaque appel.
    """
    client = get_default_client()
    return client.summarize_file(
        filepath=filepath,
        content=content
    )


# ==========================================================
# FALLBACK — résumé par fichier
# ==========================================================

EXTENSION_HINTS = {
    ".py": "Module Python",
    ".js": "Module JavaScript",
    ".ts": "Module TypeScript",
    ".java": "Classe Java",
    ".php": "Script PHP",
    ".html": "Page HTML",
    ".css": "Style CSS",
    ".sql": "Script SQL",
    ".json": "Fichier JSON"
}


def heuristic_summary(filepath, content):

    ext = os.path.splitext(filepath)[1].lower()

    file_type = EXTENSION_HINTS.get(ext, "Fichier source")

    lines = [
        x.strip()
        for x in content.splitlines()
        if x.strip()
    ]

    elements = []

    for line in lines[:100]:
        if line.startswith(("def ", "class ", "function ")):
            elements.append(line.split("(")[0])

    extra = ""

    if elements:
        extra = " Elements detectés: " + ", ".join(elements[:3])

    return (
        f"{file_type}. "
        f"Nombre de lignes: {len(lines)}."
        f"{extra}"
    )


# ==========================================================
# FALLBACK — analyse globale du projet
# ==========================================================

def _fallback_readme_content(project_name, tech_stack, dependencies=None, entry_points=None,key_files_digest=None,structure_overview=None,):
    tech_text = ", ".join(tech_stack) if tech_stack else "technologies non déterminées"
    dependency_text = ", ".join((dependencies or [])[:5]) if dependencies else "dépendances de base"
    entry_text = ", ".join((entry_points or [])[:3]) if entry_points else "points d'entrée identifiés automatiquement"
    return f"""## Description courte
{project_name} est un projet logiciel développé avec {tech_text}.
Il permet de réaliser les fonctionnalités principales présentes dans son code source.



## Objectif général
Ce projet contient les fonctionnalités principales implémentées dans son code source.
## Technologies principales
{tech_text}

## Utilisation / installation
Installer les dépendances du projet puis exécuter l'application pour générer la documentation depuis un dépôt source.

## Structure générale simple
Le projet est organisé autour d'un pipeline d'analyse, d'un générateur de documentation et d'une couche d'exposition API. {entry_text}. {dependency_text}.
"""


def _fallback_technical_documentation_content(
    project_name,
    tech_stack,
    databases,
    architecture_type,
    architecture_confidence,
    structure_overview,
    entry_points=None,
    dependencies=None,
):
    tech_text = ", ".join(tech_stack) if tech_stack else "Non déterminées"
    databases_text = ", ".join(databases) if databases else "Non détectées"
    entry_points_text = "\n".join(f"- {ep}" for ep in (entry_points or [])[:8]) if entry_points else "- Aucun point d'entrée identifié automatiquement."
    dependencies_text = "\n".join(f"- {dep}" for dep in (dependencies or [])[:12]) if dependencies else "- Aucune dépendance majeure identifiée automatiquement."
    return f"""# Documentation technique - {project_name}

## Objectif du projet
Ce projet automatise l'analyse d'un dépôt logiciel et la génération de documentation technique à partir des artefacts présents.

## Fonctionnement général
Le pipeline inspecte l'arborescence du dépôt, résume les fichiers, détecte des signaux d'architecture et produit ensuite des documents et des diagrammes de synthèse.

## Architecture détectée
Architecture : {architecture_type} (confiance : {architecture_confidence}%).

## Technologies utilisées
{tech_text}

## Structure du projet
{structure_overview or 'Structure indisponible.'}

## Modules principaux
- Pipeline d'analyse de dépôt
- Générateur de documentation
- Générateur de diagrammes

## Flux de données
Les fichiers sources sont analysés puis transformés en résumés, structures et documents de synthèse.

## Points d'entrée
{entry_points_text}

## Dépendances importantes
{dependencies_text}

## Analyse détaillée des fichiers
Les résumés de fichiers et les structures extraites servent de base à la documentation générée automatiquement.

## Recommandations
- Séparer clairement README et documentation technique.
- Maintenir une documentation à jour à chaque évolution majeure.
- Ajouter des tests autour des modules critiques.
"""


def heuristic_project_summary(
    project_name,
    tech_stack,
    databases,
    architecture_type,
    architecture_confidence,
    key_files_digest,
    existing_readme_excerpt=None,
    entry_points=None,
    dependencies=None,
):
    """
    Fallback utilisé quand Ollama est indisponible/trop lent pour
    l'analyse globale. Reste structuré avec les mêmes sections que la
    version IA, pour que le README garde une forme cohérente — mais
    sans jamais recopier le README d'origine mot pour mot : seule sa
    toute première phrase (nettoyée) sert d'indice, le reste de
    chaque section est reconstruit à partir de faits structurels
    (technologies, points d'entrée, dépendances) plutôt que de texte
    généré à partir de rien.
    """

    tech_text = ", ".join(tech_stack) if tech_stack else "Non déterminées"

    modules_text = (
        "\n".join(key_files_digest[:8])
        if key_files_digest
        else "- Aucun module clé identifié automatiquement."
    )

    entry_points_text = (
        "\n".join(f"- {ep}" for ep in entry_points)
        if entry_points
        else "- Aucun point d'entrée identifié automatiquement."
    )

    dependencies_text = (
        "\n".join(f"- {dep}" for dep in dependencies)
        if dependencies
        else "- Aucune dépendance clé identifiée automatiquement."
    )

    # Au lieu de citer un bloc entier du README (perçu comme un simple
    # copier/coller), on n'en retient que la première phrase utile,
    # comme un indice de contexte parmi d'autres faits structurels.
    first_hint = _first_meaningful_sentence(existing_readme_excerpt)

    objective_parts = [
        f"**{project_name}** est un projet "
        + (f"basé sur {tech_text}. " if tech_stack else "dont les technologies n'ont pas pu être déterminées automatiquement. ")
    ]

    if first_hint:
        objective_parts.append(
            f"D'après son README, il s'agit de : « {first_hint} »."
        )

    if not first_hint and not tech_stack:
        objective_parts.append(
            "L'objectif précis du projet n'a pas pu être déduit "
            "automatiquement (analyse IA indisponible et aucun README "
            "exploitable trouvé) : se référer au code source pour plus "
            "de détails."
        )

    objective_section = " ".join(objective_parts)

    functioning_section = (
        _build_functioning_paragraph(
            architecture_type, entry_points, tech_stack
        )
    )

    return f"""## Objectif du projet

{objective_section}

## Fonctionnement général

{functioning_section}

## Technologies utilisées

{tech_text}

## Architecture

Architecture détectée : **{architecture_type}** \
(confiance estimée : {architecture_confidence}%).

## Modules principaux

{modules_text}

## Flux de données

Flux de données non déterminé automatiquement (analyse IA indisponible) :
se référer au diagramme de flux de données généré ci-dessous pour un
schéma générique basé sur l'architecture détectée.

## Points d'entrée

{entry_points_text}

## Dépendances importantes

{dependencies_text}

## Recommandations

- Maintenir une séparation claire des responsabilités entre modules.
- Vérifier la couverture de tests des modules principaux.
- Documenter les points d'entrée du projet (API, scripts, jobs).
"""


def _first_meaningful_sentence(text, max_len=180):
    """
    Extrait la première phrase "utile" d'un texte (typiquement un
    README) : ignore les titres Markdown, badges, images et lignes
    vides, coupe à une longueur raisonnable. Retourne None si rien
    d'exploitable n'est trouvé. Volontairement limité à UNE phrase,
    pour donner un indice de contexte plutôt que de reproduire un
    passage entier du document d'origine.
    """
    if not text:
        return None

    for raw_line in text.splitlines():
        line = raw_line.strip()

        if not line:
            continue
        if line.startswith(("#", "![", "<", "[!", "[![")):
            continue
        if line.startswith(("- ", "* ", "```")):
            continue

        sentence = re.split(r"(?<=[.!?])\s", line)[0]
        sentence = sentence.strip(" .")

        if len(sentence) < 15:
            continue

        return sentence[:max_len]

    return None


def _build_functioning_paragraph(architecture_type, entry_points, tech_stack):
    """
    Paragraphe "Fonctionnement général" reconstruit à partir de faits
    structurels (architecture détectée + points d'entrée), pour éviter
    la section générique "analyse IA indisponible" quand des points
    d'entrée ont bien été identifiés.
    """
    if entry_points:
        first_entry = entry_points[0]
        return (
            f"Le projet démarre via {first_entry}, puis suit une "
            f"organisation de type **{architecture_type}**. Une analyse "
            "IA plus poussée (Ollama) permettrait de détailler "
            "précisément l'enchaînement des appels entre modules."
        )

    return (
        f"Aucun point d'entrée explicite n'a été identifié "
        f"automatiquement. Le projet semble organisé selon une "
        f"architecture de type **{architecture_type}** ; se référer à "
        "la structure du projet ci-dessous pour identifier le point "
        "de démarrage."
    )