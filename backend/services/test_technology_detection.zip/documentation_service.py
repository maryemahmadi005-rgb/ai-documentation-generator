"""
documentation_service.py

Pipeline complet:

GitHub URL
    ->
clone repository
    ->
git analysis
    ->
AI summaries
    ->
architecture detection
    ->
documentation generation

No database operations.
"""

import os
import re
import subprocess
import time

from services.git_service import clone_repository

from services.analyzers.git_analyzer import GitAnalyzer

from services.ollama_client import (
    get_default_client,
    heuristic_summary,
)

from services.analyzers.architecture_analyzer import (
    detect_architecture,
    build_comparison_markdown,
    generate_mermaid_diagram,
    generate_architecture_layers_diagram,
    generate_dataflow_diagram,
    generate_module_dependency_diagram,
)

from services.doc_builder import DocBuilder
from services.document_service import create_document

class DocumentationPipelineError(Exception):
    pass


# ==========================================================
# Réglages de performance
# ==========================================================
#
# Nombre maximum de fichiers envoyés au LLM. Avant cette optimisation,
# TOUS les fichiers texte du repo étaient envoyés à Ollama un par un :
# c'était la cause principale des temps d'analyse très longs. Les
# fichiers non sélectionnés reçoivent quand même un résumé (via le
# fallback heuristique local, rapide), donc la doc reste complète.
MAX_AI_SUMMARIES = int(os.environ.get("DOC_MAX_AI_SUMMARIES", "100 "))

# Par défaut, DÉSACTIVÉ : un seul appel IA global (analyze_project)
# suffit pour produire la documentation, conformément à l'objectif de
# performance ("une seule requête IA globale"). Les résumés par
# fichier utilisent alors uniquement le fallback heuristique local
# (rapide, sans appel réseau), ce qui élimine à la fois la latence de
# jusqu'à MAX_AI_SUMMARIES appels IA supplémentaires et le risque de
# contenu redondant entre résumés de fichiers et synthèse globale.
# Remettre à "true" pour retrouver l'ancien comportement (résumé IA
# par fichier prioritaire, en plus de l'analyse globale).
ENABLE_PER_FILE_AI_SUMMARIES = (
    os.environ.get("DOC_ENABLE_PER_FILE_AI_SUMMARIES", "false").lower() == "true"
)

# Budget de temps total pour la phase de résumés IA. Une fois ce
# budget dépassé, tous les fichiers restants basculent automatiquement
# sur le résumé heuristique, ce qui garantit un temps d'analyse borné
# même si Ollama répond lentement sans pour autant déclencher le
# circuit breaker (ex : réponses lentes mais valides).
AI_SUMMARY_TIME_BUDGET_SECONDS = int(
    os.environ.get("DOC_AI_TIME_BUDGET_SECONDS", "120")
)

# Nombre minimal de lignes qu'un fichier doit contenir pour être
# considéré comme pertinent (évite de documenter des fichiers vides,
# des stubs ou des fichiers générés quasi vides).
MIN_FILE_LINES = int(os.environ.get("DOC_MIN_FILE_LINES", "10"))

# Noms de fichiers considérés comme des points d'entrée / fichiers clés
# d'un projet, donc prioritaires pour un résumé par IA.
PRIORITY_FILENAMES = {
    "app.py", "main.py", "manage.py", "wsgi.py", "asgi.py",
    "settings.py", "urls.py", "routes.py", "models.py",
    "server.js", "index.js", "index.ts", "app.js", "app.tsx",
    "app.jsx", "index.php", "artisan", "index.html",
}

# Fragments de chemin pénalisant la priorité (tests, fichiers générés,
# dépendances verrouillées, migrations...).
LOW_PRIORITY_HINTS = ("test", "spec", "migrations", "__pycache__", ".lock")


# ==========================================================
# Filtrage des fichiers / dossiers non pertinents
# ==========================================================
#
# Ces dossiers ne contiennent jamais de code métier : ce sont soit des
# artefacts générés (build, dist, site mkdocs...), soit des
# dépendances (node_modules, venv...), soit des caches / VCS internes.
IGNORED_DIR_NAMES = {
    ".git", ".cache", "output", "generated_docs", "generated-docs",
    "doc-output", "site", "venv", ".venv", "node_modules",
    "__pycache__", "dist", "build",
}

# Suffixes de fichiers temporaires / non pertinents pour la doc.
TEMP_FILE_SUFFIXES = (".tmp", ".temp", ".swp", ".bak", ".log", "~")

# Extensions de code source considérées comme pertinentes à analyser.
# Tout le reste (assets, fichiers de config figés, images, etc.) est
# ignoré par le pipeline de documentation.
RELEVANT_EXTENSIONS = {

    # Backend
    ".py",
    ".java",
    ".php",
    ".go",
    ".rb",

    # Frontend
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
    ".ts",
    ".tsx",

    # Documentation
    ".md",
    ".mdx",

    # Configuration
    ".json",
    ".yaml",
    ".yml",
    ".toml",

    # Styles
    ".css",
    ".scss",

}


def _is_temporary_file(filename: str) -> bool:
    lower = filename.lower()
    return lower.endswith(TEMP_FILE_SUFFIXES) or filename.startswith(".~")


def _is_ignored_path(path: str) -> bool:
    """
    True si le fichier se trouve dans un dossier généré/caché, ou si
    c'est lui-même un fichier caché / temporaire.
    """
    normalized = path.replace("\\", "/")
    segments = [s for s in normalized.split("/") if s]

    if not segments:
        return True

    filename = segments[-1]
    dir_segments = segments[:-1]

    for segment in dir_segments:
        if segment in IGNORED_DIR_NAMES:
            return True
        if segment.startswith("."):
            return True

    # Cas particulier du site MkDocs généré : docs/site/...
    if "docs/site/" in normalized or normalized.startswith("docs/site/"):
        return True

    if filename.startswith("."):
        return True

    if _is_temporary_file(filename):
        return True

    return False


def _is_relevant_source_file(path: str) -> bool:
    ext = os.path.splitext(path)[1].lower()
    return ext in RELEVANT_EXTENSIONS


def _filter_source_files(text_files):
    """
    Ne garde que les fichiers de code source pertinents, en excluant
    les dossiers générés/cachés et les extensions non pertinentes.
    """
    return [
        f for f in text_files
        if not _is_ignored_path(f["path"])
        and _is_relevant_source_file(f["path"])
    ]


def _select_ai_candidate_files(text_files):
    """
    Sélectionne les fichiers pertinents pour l'analyse IA, en incluant
    les documents et fichiers de configuration utiles au contexte du
    dépôt, sans inclure les assets binaires ou médias.
    """
    return [
        f for f in text_files
        if not _is_ignored_path(f["path"])
        and _is_relevant_source_file(f["path"])
    ]


def _count_lines(content: str) -> int:
    if not content:
        return 0
    return content.count("\n") + 1


# ==========================================================
# Extraction légère de structure de code (heuristique, pas d'AST)
# ==========================================================
#
# Objectif : donner à la doc des informations concrètes (classes,
# fonctions, dépendances, endpoints API) sans dépendre d'un parseur
# complet par langage. C'est volontairement basé sur des regex :
# suffisant pour une vue d'ensemble lisible, pas pour une analyse
# exhaustive.

_PY_PATTERNS = {
    "class": re.compile(r'^[ \t]*class\s+(\w+)', re.MULTILINE),
    "function": re.compile(r'^[ \t]*def\s+(\w+)\s*\(', re.MULTILINE),
    "import": re.compile(
        r'^[ \t]*(?:from\s+([\w\.]+)\s+import|import\s+([\w\.]+))',
        re.MULTILINE,
    ),
    "api": re.compile(
        r'@(?:\w+)\.(?:route|get|post|put|delete|patch)\(\s*[\'"]([^\'"]+)[\'"]',
        re.MULTILINE,
    ),
}

_JS_PATTERNS = {
    "class": re.compile(r'(?:export\s+)?class\s+(\w+)', re.MULTILINE),
    "function": re.compile(
        r'(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\('
        r'|(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>',
        re.MULTILINE,
    ),
    "import": re.compile(
        r'(?:import\s+.*?from\s+|require\(\s*)[\'"]([^\'"]+)[\'"]',
        re.MULTILINE,
    ),
    "api": re.compile(
        r'(?:router|app)\.(?:get|post|put|delete|patch)\(\s*[\'"]([^\'"]+)[\'"]',
        re.MULTILINE,
    ),
}

_PHP_PATTERNS = {
    "class": re.compile(r'class\s+(\w+)', re.MULTILINE),
    "function": re.compile(r'function\s+(\w+)\s*\(', re.MULTILINE),
    "import": re.compile(r'use\s+([\w\\]+)\s*;', re.MULTILINE),
    "api": re.compile(
        r'Route::(?:get|post|put|delete|patch)\(\s*[\'"]([^\'"]+)[\'"]',
        re.MULTILINE,
    ),
}

_JAVA_LIKE_PATTERNS = {
    "class": re.compile(r'class\s+(\w+)', re.MULTILINE),
    "function": re.compile(
        r'(?:public|private|protected|static|final|\s)+[\w<>\[\],\s]+\s+'
        r'(\w+)\s*\([^)]*\)\s*\{',
        re.MULTILINE,
    ),
    "import": re.compile(r'(?:import|using)\s+([\w\.]+)\s*;', re.MULTILINE),
    "api": re.compile(
        r'@(?:GetMapping|PostMapping|PutMapping|DeleteMapping|RequestMapping)'
        r'\(\s*[\'"]([^\'"]+)[\'"]',
        re.MULTILINE,
    ),
}

_GO_PATTERNS = {
    "class": re.compile(r'type\s+(\w+)\s+struct', re.MULTILINE),
    "function": re.compile(r'func\s+(?:\([^)]*\)\s*)?(\w+)\s*\(', re.MULTILINE),
    "import": re.compile(r'^\s*"([\w\./\-]+)"', re.MULTILINE),
    "api": re.compile(
        r'\.(?:GET|POST|PUT|DELETE|PATCH)\(\s*"([^"]+)"',
        re.MULTILINE,
    ),
}

_EXTENSION_PATTERNS = {
    ".py": _PY_PATTERNS,
    ".js": _JS_PATTERNS, ".jsx": _JS_PATTERNS, ".mjs": _JS_PATTERNS,
    ".cjs": _JS_PATTERNS, ".ts": _JS_PATTERNS, ".tsx": _JS_PATTERNS,
    ".vue": _JS_PATTERNS,
    ".php": _PHP_PATTERNS,
    ".java": _JAVA_LIKE_PATTERNS, ".kt": _JAVA_LIKE_PATTERNS,
    ".cs": _JAVA_LIKE_PATTERNS,
    ".go": _GO_PATTERNS,
}

_EMPTY_STRUCTURE = {
    "classes": [], "functions": [], "imports": [], "api_endpoints": [],
}


def _find_all(pattern, content, join_groups=False):
    if pattern is None:
        return []

    results = []

    for match in pattern.finditer(content):
        groups = [g for g in match.groups() if g]

        if not groups:
            continue

        results.append(" ".join(groups) if join_groups else groups[0])

    return results


def _dedupe_limit(values, limit):
    seen = []
    for value in values:
        if value not in seen:
            seen.append(value)
        if len(seen) >= limit:
            break
    return seen


def _extract_code_structure(path: str, content: str) -> dict:
    """
    Extraction heuristique (regex, pas d'AST) des classes, fonctions,
    imports et endpoints API d'un fichier. Suffisant pour donner une
    vue d'ensemble lisible dans la doc générée.
    """
    ext = os.path.splitext(path)[1].lower()
    patterns = _EXTENSION_PATTERNS.get(ext)

    if not patterns or not content:
        return dict(_EMPTY_STRUCTURE)

    return {
        "classes": _dedupe_limit(
            _find_all(patterns.get("class"), content), 8
        ),
        "functions": _dedupe_limit(
            _find_all(patterns.get("function"), content), 15
        ),
        "imports": _dedupe_limit(
            _find_all(patterns.get("import"), content), 12
        ),
        "api_endpoints": _dedupe_limit(
            _find_all(patterns.get("api"), content, join_groups=True), 10
        ),
    }


def _build_architecture_explanation(architecture_result: dict) -> str:
    """
    Construit une explication lisible de l'architecture détectée, à
    partir de ce que `detect_architecture()` retourne déjà (type,
    confiance, signaux, classement complet). Ne modifie pas la
    logique de détection elle-même.
    """
    arch_type = architecture_result.get("type") or "Non déterminée"
    confidence = architecture_result.get("confidence_pct")
    score_out_of_10 = architecture_result.get("score_out_of_10")
    signals = architecture_result.get("signals", [])
    ranking = architecture_result.get("full_ranking", [])

    parts = [
        f"Architecture détectée : {arch_type}"
        + (f" (confiance {confidence}%)" if confidence is not None else "")
        + (
            f", score {score_out_of_10}/10"
            if score_out_of_10 is not None
            else ""
        )
        + "."
    ]

    if signals:
        parts.append(
            "Signaux principaux ayant motivé cette détection : "
            + "; ".join(signals[:5]) + "."
        )

    alternatives = [
        item for item in ranking
        if item.get("type") != arch_type
    ][:2]

    if alternatives:
        alt_text = ", ".join(
            f"{item.get('type')} ({item.get('confidence_pct')}%)"
            for item in alternatives
        )
        parts.append(
            f"Architectures alternatives envisagées : {alt_text}."
        )

    ambiguous_with = architecture_result.get("ambiguous_with")

    if ambiguous_with:
        parts.append(
            f"Attention : le score est proche de celui de "
            f"« {ambiguous_with} », la distinction n'est pas "
            f"totalement tranchée."
        )

    return " ".join(parts)


def _build_files_list(file_summaries: dict) -> list:
    """
    Transforme le dict interne file_summaries (path -> {summary,
    line_count, structure}) en une liste à plat sérialisable en JSON,
    prête à être renvoyée à l'API / au frontend.
    """
    return [
        {
            "path": path,
            "line_count": data.get("line_count", 0),
            "classes": data.get("structure", {}).get("classes", []),
            "functions": data.get("structure", {}).get("functions", []),
            "imports": data.get("structure", {}).get("imports", []),
            "api_endpoints": data.get("structure", {}).get("api_endpoints", []),
            "summary": data.get("summary", ""),
        }
        for path, data in file_summaries.items()
    ]


# Mapping extension -> technologie, utilisé pour construire la liste
# des technologies détectées passée au prompt d'analyse globale.
EXTENSION_TO_TECH = {
    ".py": "Python",
    ".js": "JavaScript", ".jsx": "JavaScript (React)",
    ".mjs": "JavaScript", ".cjs": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript (React)",
    ".vue": "Vue.js",
    ".java": "Java", ".kt": "Kotlin",
    ".go": "Go",
    ".cs": "C#",
    ".php": "PHP",
    ".rb": "Ruby",
    ".c": "C", ".cpp": "C++", ".h": "C/C++", ".hpp": "C++",
    ".rs": "Rust",
    ".swift": "Swift",
}


READMES_CANDIDATES = (
    "README.md", "Readme.md", "readme.md",
    "README.rst", "README.txt", "README",
)

# Nombre de caractères max du README d'origine transmis au prompt IA
# (pour rester dans un budget de contexte raisonnable).
README_EXCERPT_MAX_CHARS = 1000


def _read_project_readme(repo_path: str):
    """
    Lit le README d'origine du projet (s'il existe) directement depuis
    le repo cloné, indépendamment du pipeline d'analyse fichier par
    fichier (s'il existe) directement depuis le dépôt cloné, en
    complément du pipeline d'analyse fichier par fichier. Sert de
    contexte supplémentaire pour l'analyse IA globale : évite le
    fallback générique "objectif non déduit" quand un README existe
    déjà et décrit le projet.
    """
    for candidate in READMES_CANDIDATES:
        candidate_path = os.path.join(repo_path, candidate)

        if os.path.isfile(candidate_path):
            try:
                content = GitAnalyzer.read_file(candidate_path)
            except Exception:
                content = None

            if content:
                return content[:README_EXCERPT_MAX_CHARS]

    return None


def _count_directories(structure) -> int:
    if not isinstance(structure, dict):
        return 0

    count = 0

    for child in structure.get("dirs", {}).values():
        count += 1 + _count_directories(child)

    return count


def _infer_tech_stack(file_summaries):
    techs = set()

    for path in file_summaries.keys():
        ext = os.path.splitext(path)[1].lower()
        tech = EXTENSION_TO_TECH.get(ext)
        if tech:
            techs.add(tech)

    return sorted(techs)


# ==========================================================
# Détection enrichie des technologies (au-delà des extensions)
# ==========================================================
#
# Repère, via des fichiers/signatures caractéristiques, le framework,
# la base de données, l'ORM, le gestionnaire de paquets, la
# containerisation, la CI/CD, les tests, la documentation, le cloud et
# l'IA utilisés. Complète `_infer_tech_stack` (basé sur les extensions)
# sans le remplacer : le champ `technologies` reste une liste plate de
# chaînes, compatible avec l'existant (DB, frontend, API).

_TECH_SIGNATURE_FILES = {
    "package.json": "Node.js",
    "requirements.txt": "pip (Python)",
    "pyproject.toml": "Python (pyproject)",
    "Pipfile": "Pipenv",
    "composer.json": "Composer (PHP)",
    "pom.xml": "Maven (Java)",
    "build.gradle": "Gradle (Java/Kotlin)",
    "Gemfile": "Bundler (Ruby)",
    "go.mod": "Go Modules",
    "Cargo.toml": "Cargo (Rust)",
    "Dockerfile": "Docker",
    "docker-compose.yml": "Docker Compose",
    "docker-compose.yaml": "Docker Compose",
    "mkdocs.yml": "MkDocs",
    "serverless.yml": "Serverless Framework",
    "pytest.ini": "Pytest",
    "jest.config.js": "Jest",
    "phpunit.xml": "PHPUnit",
    ".flaskenv": "Flask",
}

_PACKAGE_JSON_DEP_HINTS = {
    "react": "React", "vue": "Vue.js", "next": "Next.js",
    "express": "Express.js", "@nestjs/core": "NestJS",
    "mongoose": "MongoDB (Mongoose)", "sequelize": "Sequelize ORM",
    "typeorm": "TypeORM", "prisma": "Prisma ORM",
    "axios": "Axios", "tailwindcss": "Tailwind CSS",
}

_REQUIREMENTS_DEP_HINTS = {
    "flask": "Flask", "django": "Django", "fastapi": "FastAPI",
    "sqlalchemy": "SQLAlchemy ORM", "psycopg2": "PostgreSQL",
    "pymongo": "MongoDB", "redis": "Redis",
    "celery": "Celery", "ollama": "Ollama (LLM local)",
    "openai": "OpenAI API", "langchain": "LangChain",
    "pytest": "Pytest",
}
_DATABASE_HINTS = {
    "sqlite": "SQLite",
    "mysql": "MySQL",
    "postgres": "PostgreSQL",
    "postgresql": "PostgreSQL",
    "mongodb": "MongoDB",
}
def _detect_technologies_with_evidence(repo_path, file_summaries=None):
    """
    Détecte les technologies à partir de preuves visibles dans le dépôt
    (dépendances, fichiers de config, imports, extensions) et retourne
    une structure compatible avec les besoins existants : une liste de
    dictionnaires {name, evidence}. L'API / frontend restent inchangés
    car la liste plate de technologies reste construite plus bas.
    """
    detections = []
    evidence_map = {}

    def add_tech(name, evidence):
        if not name:
            return
        if name not in evidence_map:
            evidence_map[name] = []
        if evidence not in evidence_map[name]:
            evidence_map[name].append(evidence)

    try:
        root_files = set(os.listdir(repo_path))
    except OSError:
        return []

    for filename, label in _TECH_SIGNATURE_FILES.items():
        if filename in root_files:
            add_tech(label, f"fichier racine: {filename}")

    if ".github" in root_files and os.path.isdir(os.path.join(repo_path, ".github", "workflows")):
        add_tech("GitHub Actions", "dossier .github/workflows")

    package_json_path = os.path.join(repo_path, "package.json")
    if os.path.isfile(package_json_path):
        try:
            import json as _json
            with open(package_json_path, encoding="utf-8") as f:
                pkg = _json.load(f)
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            for dep_name, version in deps.items():
                if dep_name in _PACKAGE_JSON_DEP_HINTS:
                    add_tech(_PACKAGE_JSON_DEP_HINTS[dep_name], f"package.json: dépendance {dep_name}")
                if dep_name in {"vite", "vitest", "tailwindcss", "typescript", "react", "next"}:
                    add_tech("Vite", "package.json: vite")
            if "next" in deps:
                add_tech("Next.js", "package.json: next")
            if "react" in deps:
                add_tech("React", "package.json: react")
            if "tailwindcss" in deps:
                add_tech("Tailwind CSS", "package.json: tailwindcss")
            if "typescript" in deps:
                add_tech("TypeScript", "package.json: typescript")
            if "vite" in deps:
                add_tech("Vite", "package.json: vite")
        except Exception:
            pass

    requirements_path = os.path.join(repo_path, "requirements.txt")
    if os.path.isfile(requirements_path):
        try:
            with open(requirements_path, encoding="utf-8") as f:
                req_lines = [line.strip() for line in f.readlines() if line.strip() and not line.startswith("#")]
            for line in req_lines:
                pkg_name = re.split(r"[=<>~!\[]", line)[0].strip().lower()
                if pkg_name in _REQUIREMENTS_DEP_HINTS:
                    add_tech(_REQUIREMENTS_DEP_HINTS[pkg_name], f"requirements.txt: {pkg_name}")
                for db_key, db_name in _DATABASE_HINTS.items():
                    if db_key in pkg_name:
                        add_tech(db_name, f"requirements.txt: {pkg_name}")
        except Exception:
            pass

    for filename in ("next.config.js", "next.config.mjs", "next.config.ts", "vite.config.js", "vite.config.ts", "vite.config.mjs", "tsconfig.json", "mkdocs.yml", "docker-compose.yml", "docker-compose.yaml", "Dockerfile"):
        if filename in root_files:
            if filename.startswith("next.config"):
                add_tech("Next.js", f"fichier racine: {filename}")
            elif filename.startswith("vite.config"):
                add_tech("Vite", f"fichier racine: {filename}")
            elif filename == "tsconfig.json":
                add_tech("TypeScript", f"fichier racine: {filename}")
            elif filename == "mkdocs.yml":
                add_tech("MkDocs", f"fichier racine: {filename}")
            elif filename in {"docker-compose.yml", "docker-compose.yaml", "Dockerfile"}:
                add_tech("Docker", f"fichier racine: {filename}")

    if file_summaries:
        for path, data in file_summaries.items():
            lower_path = path.lower()
            if lower_path.endswith((".md", ".mdx")):
                add_tech("MDX", f"fichier: {path}")
            if lower_path.endswith((".yaml", ".yml")):
                add_tech("YAML", f"fichier: {path}")
            if lower_path.endswith(".tsx"):
                add_tech("TypeScript", f"fichier: {path}")
            if lower_path.endswith(".jsx"):
                add_tech("JavaScript", f"fichier: {path}")
            if lower_path.endswith(".mdx"):
                add_tech("MDX", f"fichier: {path}")
            if lower_path.endswith((".md", ".mdx")) and any(token in lower_path for token in ("docs", "doc")):
                add_tech("Docusaurus", f"fichier: {path}")
            if "openapi" in lower_path or "swagger" in lower_path:
                add_tech("OpenAPI", f"fichier: {path}")
            if "asyncapi" in lower_path:
                add_tech("AsyncAPI", f"fichier: {path}")

    for name, evidence_items in evidence_map.items():
        detections.append({"name": name, "evidence": evidence_items})

    return sorted(detections, key=lambda item: item["name"].lower())


def _detect_database_from_files(file_summaries):
    databases = set()

    for path, data in file_summaries.items():

        structure = data.get("structure", {})

        imports = structure.get("imports", [])

        for imp in imports:
            imp = imp.lower()

            for key, value in _DATABASE_HINTS.items():
                if key in imp:
                    databases.add(value)

    return sorted(databases)


def _detect_technology_signals(repo_path):
    """
    Retourne (technologies_supplémentaires: list[str], dependencies:
    list[str]) détectées via des fichiers signatures à la racine du
    projet, sans dépendre du LLM.
    """
    evidence = _detect_technologies_with_evidence(repo_path)
    extra_techs = [item["name"] for item in evidence]
    dependencies = []

    try:
        root_files = set(os.listdir(repo_path))
    except OSError:
        return [], []

    if ".github" in root_files and os.path.isdir(os.path.join(repo_path, ".github", "workflows")):
        extra_techs.append("GitHub Actions")

    package_json_path = os.path.join(repo_path, "package.json")
    if os.path.isfile(package_json_path):
        try:
            import json as _json
            with open(package_json_path, encoding="utf-8") as f:
                pkg = _json.load(f)
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            dependencies += [f"{name}@{version}" for name, version in list(deps.items())[:10]]
        except Exception:
            pass

    requirements_path = os.path.join(repo_path, "requirements.txt")
    if os.path.isfile(requirements_path):
        try:
            with open(requirements_path, encoding="utf-8") as f:
                req_lines = [line.strip() for line in f.readlines() if line.strip() and not line.startswith("#")]
            dependencies += req_lines[:10]
        except Exception:
            pass

    return sorted(set(extra_techs)), dependencies


def _detect_entry_points(important_files):
    """
    Formate les points d'entrée déjà identifiés (via PRIORITY_FILENAMES
    dans _score_file) en libellés lisibles pour les sections "Points
    d'entrée" du résumé (IA ou heuristique).
    """
    entry_points = []

    for file_info in important_files:
        filename = os.path.basename(file_info["path"]).lower()
        if filename in PRIORITY_FILENAMES:
            entry_points.append(f"`{file_info['path']}`")

    return entry_points[:6]



def _build_structure_overview(structure, max_depth=1, max_lines=30):
    """
    Rendu texte compact de l'arborescence (profondeur limitée), pour
    donner du contexte au prompt d'analyse globale sans le saturer.
    """
    lines = []

    def walk(node, prefix="", depth=0):
        if not isinstance(node, dict) or depth > max_depth:
            return

        for filename in sorted(node.get("files", []))[:15]:
            lines.append(f"{prefix}{filename}")

        for folder, child in sorted(node.get("dirs", {}).items()):
            lines.append(f"{prefix}{folder}/")
            walk(child, prefix + "  ", depth + 1)

    walk(structure)

    if not lines:
        return "Structure indisponible."

    return "\n".join(lines[:max_lines])


def _build_key_files_digest(file_summaries, important_paths, limit=8):
    """
    Court résumé (une ligne par fichier) des fichiers jugés
    prioritaires, pour ancrer l'analyse IA globale sur des éléments
    concrets du projet plutôt que sur la seule arborescence.
    """
    digest = []

    for path in important_paths:

        data = file_summaries.get(path)

        if not data:
            continue

        summary_lines = (data.get("summary") or "").strip().splitlines()
        first_line = summary_lines[0] if summary_lines else ""

        digest.append(f"- `{path}` : {first_line}")

        if len(digest) >= limit:
            break

    return digest
def _build_code_overview(file_summaries, limit=10):

    sections = []

    for path, data in list(file_summaries.items())[:limit]:

        structure = data.get("structure", {})

        filename = os.path.basename(path)

        functions = structure.get("functions", [])
        classes = structure.get("classes", [])
        imports = structure.get("imports", [])

        section = f"""
### {filename}

Role:
{data.get("summary", "No description available")}

Classes:
{", ".join(classes) if classes else "None"}

Functions:
{", ".join(functions) if functions else "None"}

Dependencies:
{", ".join(imports) if imports else "None"}
"""

        sections.append(section)

    return "\n".join(sections)


def _build_technical_documentation_content(
    project_name,
    ai_summary,
    architecture_explanation,
    tech_stack,
    dependencies,
    entry_points,
    structure,
    file_summaries,
):
    objective = ""
    if ai_summary:
        objective = "\n".join(
            line.strip() for line in ai_summary.splitlines() if line.strip()
        )
    if not objective:
        objective = (
            f"{project_name} est un projet logiciel dont l'objectif est "
            "d'automatiser l'analyse et la documentation du dépôt."
        )

    workflow = (
        "Le système analyse automatiquement les fichiers du dépôt, "
        "détecte l'architecture et génère une documentation technique "
        "ainsi que des diagrammes de structure et de dépendances."
    )
    if entry_points:
        workflow += (
            " Les points d'entrée principaux observés sont "
            + ", ".join(entry_points[:4])
            + "."
        )
    if dependencies:
        workflow += (
            " Les dépendances importantes détectées incluent "
            + ", ".join(dependencies[:6])
            + "."
        )

    technologies = ", ".join(tech_stack) if tech_stack else "Non déterminées"
    structure_overview = _build_structure_overview(structure, max_depth=2, max_lines=40)
    recommendations = [
        "Conserver une séparation nette entre le README de présentation et la documentation technique complète.",
        "Documenter les interfaces et dépendances lors des évolutions majeures.",
        "Ajouter des tests automatisés autour des modules critiques pour sécuriser l'évolution du système.",
    ]

    lines = [
        f"# Documentation technique - {project_name}",
        "",
        "## Objectif du projet",
        "",
        objective,
        "",
        "## Description générale du fonctionnement",
        "",
        workflow,
        "",
        "## Architecture détectée",
        "",
        architecture_explanation or "Architecture non déterminée.",
        "",
        "## Technologies utilisées",
        "",
        technologies,
        "",
        "## Structure du projet",
        "",
        "```text",
        structure_overview or "Structure indisponible.",
        "```",
        "",
        "## Modules principaux",
        "",
    ]

    module_entries = []
    for path, data in sorted(file_summaries.items())[:12]:
        summary = (data.get("summary") or "Résumé indisponible").strip().splitlines()[0]
        module_entries.append(f"- **{path}** : {summary}")
    if module_entries:
        lines.extend(module_entries)
    else:
        lines.append("- Aucun module principal n'a été identifié automatiquement.")

    lines.extend([
        "",
        "## Flux de données",
        "",
        "Le flux principal part des fichiers sources du dépôt, passe par l'analyse structurelle et l'analyse IA, puis produit des fichiers de documentation et des diagrammes de synthèse.",
        "",
        "## Points d'entrée",
        "",
    ])

    if entry_points:
        lines.extend(f"- {entry_point}" for entry_point in entry_points[:8])
    else:
        lines.append("- Aucun point d'entrée explicite n'a été détecté automatiquement.")

    lines.extend([
        "",
        "## Dépendances importantes",
        "",
    ])

    if dependencies:
        lines.extend(f"- {dependency}" for dependency in dependencies[:12])
    else:
        lines.append("- Aucune dépendance majeure n'a été identifiée automatiquement.")

    lines.extend([
        "",
        "## Recommandations",
        "",
    ])
    lines.extend(f"- {recommendation}" for recommendation in recommendations)
    lines.extend([
        "",
        "## Analyse détaillée des fichiers",
        "",
    ])

    for path, data in sorted(file_summaries.items()):
        structure = data.get("structure", {})
        summary = (data.get("summary") or "Résumé indisponible").strip()
        classes = ", ".join(structure.get("classes", [])) or "Aucune"
        functions = ", ".join(structure.get("functions", [])) or "Aucune"
        imports = ", ".join(structure.get("imports", [])) or "Aucune"

        lines.extend([
            f"### {path}",
            "",
            summary,
            "",
            f"- Classes : {classes}",
            f"- Fonctions : {functions}",
            f"- Dépendances : {imports}",
            "",
        ])

    return "\n".join(lines)


def _select_important_files(text_files, max_files=None):

    ranked = []

    for file_info in text_files:

        try:
            content = GitAnalyzer.read_file(
                file_info["full_path"]
            )

            score = _advanced_score_file(
                file_info,
                content or ""
            )

            file_info["importance_score"] = score

            ranked.append(file_info)

        except Exception:
            continue


    ranked.sort(
        key=lambda x:x.get(
            "importance_score",
            0
        ),
        reverse=True
    )

    if max_files is None:
        max_files = int(os.environ.get("DOC_IMPORTANT_FILES_LIMIT", "35"))

    return ranked[:max_files]


def _score_file(file_info):
    """
    Calcule un score d'importance pour un fichier, sans lire son
    contenu (uniquement chemin + taille déjà connus). Plus le score
    est élevé, plus le fichier est prioritaire pour un résumé IA.
    """
    path_lower = file_info["path"].lower()
    filename = os.path.basename(path_lower)

    score = 0

    if filename in PRIORITY_FILENAMES:
        score += 12_000

    if any(hint in path_lower for hint in LOW_PRIORITY_HINTS):
        score -= 6_000

    if any(path_lower.endswith(ext) for ext in (".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".php")):
        score += 200

    if path_lower.endswith(("/routes.py", "/routes.js", "/routes.ts", "/app.py", "/main.py", "/server.py", "/index.js", "/index.ts", "/index.jsx", "/index.tsx")):
        score += 800

    if any(token in path_lower for token in ("/routes/", "/router/", "/controllers/", "/services/", "/models/", "/components/", "/src/", "/app/")):
        score += 400

    if filename in {"package.json", "requirements.txt", "pyproject.toml", "setup.py", "manage.py", "dockerfile", "docker-compose.yml", "docker-compose.yaml", "mkdocs.yml", "vite.config.js", "next.config.js", "tsconfig.json"}:
        score += 1500

    if filename.startswith("readme"):
        score += 1000

    if filename.endswith((".env", ".example", ".sample")):
        score -= 800

    score += min(file_info["size"], 18_000)

    return score
def _advanced_score_file(file_info, content):

    path = file_info["path"].lower()
    filename = os.path.basename(path).lower()

    score = _score_file(file_info)

    content_lower = content.lower()


    # ==================================
    # 1) Fichiers clés du projet
    # ==================================

    if filename in [
        "package.json",
        "requirements.txt",
        "pyproject.toml",
        "dockerfile",
        "docker-compose.yml",
        "docker-compose.yaml",
        "mkdocs.yml",
        "vite.config.js",
        "next.config.js",
        "tsconfig.json",
    ]:
        score += 600

    if filename.startswith("readme"):
        score += 500

    # ==================================
    # 2) Architecture files
    # ==================================

    if any(x in path for x in [
        "app.",
        "main.",
        "server.",
        "index.",
        "routes",
        "router",
        "controller",
        "controllers",
        "service",
        "services",
        "model",
        "models",
        "components",
        "src/",
        "app/",
    ]):
        score += 260



    # ==================================
    # 3) Documentation utile
    # ==================================

    ext = os.path.splitext(filename)[1]

    if ext in [
        ".md",
        ".mdx"
    ]:
        score += 100



    # ==================================
    # 4) Configuration utile
    # ==================================

    if filename in [
        "docs.json",
        "mkdocs.yml",
        "vite.config.js",
        "next.config.js",
        "tsconfig.json",
    ]:
        score += 250



    # ==================================
    # 5) Code signals
    # ==================================

    keywords = {
        "flask": 100,
        "fastapi": 100,
        "express": 100,
        "react": 80,
        "sqlalchemy": 80,
        "mongoose": 80,
        "router": 50,
        "@app.route": 80,
    }


    for word, value in keywords.items():

        if word in content_lower:
            score += value



    # ==================================
    # 6) Penalités
    # ==================================

    # OpenAPI generated files
    if "openapi" in filename:
        score -= 150


    if "asyncapi" in filename:
        score -= 100


    # Translation files
    if filename in [
        "fr.json",
        "es.json",
        "zh.json",
        "en.json",
    ]:
        score -= 150


    # CSS
    if ext in [
        ".css",
        ".scss"
    ]:
        score -= 100


    # Tests
    if any(x in path for x in [
        "test",
        "spec",
        "mock",
    ]):
        score -= 100



    return score
def _build_code_inventory(
    file_summaries,
    important_paths,
    limit=10
):

    sections = []

    for path in important_paths:

        if path not in file_summaries:
            continue

        data = file_summaries[path]

        structure = data.get("structure", {})

        filename = os.path.basename(path)

        sections.append(f"""
### {filename}

Path:
{path}

Role:
{data.get("summary", "No description")}

Classes:
{", ".join(structure.get("classes", [])) or "None"}

Functions:
{", ".join(structure.get("functions", [])) or "None"}

Dependencies:
{", ".join(structure.get("imports", [])) or "None"}

""")

        if len(sections) >= limit:
            break

    return "\n".join(sections)
def _build_dependencies(repo_path, file_summaries):
    dependencies = []

    # Lire requirements.txt
    requirements_path = os.path.join(
        repo_path,
        "requirements.txt"
    )

    if os.path.exists(requirements_path):
        with open(
            requirements_path,
            "r",
            encoding="utf-8"
        ) as f:
            for line in f:
                line = line.strip()

                if line and not line.startswith("#"):
                    dependencies.append(line)


    # Ajouter imports détectés
    imports = set()

    for data in file_summaries.values():
        structure = data.get("structure", {})

        for imp in structure.get("imports", []):
            imports.add(imp)


    for imp in sorted(imports):
        if imp not in dependencies:
            dependencies.append(imp)


    return dependencies[:20]
IGNORED_TREE_DIRS = {
    "images",
    "files",
    "node_modules",
    ".git",
    "dist",
    "build",
    "__pycache__",
    "coverage",
    "fr",
    "es",
    "zh",
}


def filter_tree_structure(structure):

    if not isinstance(structure, dict):
        return structure

    cleaned = {}

    for name, value in structure.items():

        if name.lower() in IGNORED_TREE_DIRS:
            continue

        if isinstance(value, dict):
            cleaned[name] = filter_tree_structure(value)

        else:
            cleaned[name] = value

    return cleaned

def generate_documentation(
    github_url: str,
    analysis_id,
    log_callback=None
    ):
    print("🚀 START generate_documentation")
    def log(level, message):
        if log_callback:
            log_callback(level, message)

    try:

        # ==================================================
        # 1) Clone repository
        # ==================================================

        log("INFO", "Clonage du dépôt GitHub...")
        print("START CLONE")

        repo_path = clone_repository(github_url)
        print("CLONE DONE:", repo_path)

        log("INFO", f"Dépôt cloné : {repo_path}")

        # ==================================================
        # 2) Git analysis
        # ==================================================

        log("INFO", "Analyse du repository...")

        analyzer = GitAnalyzer(repo_path)
        print("REPO PATH =", repo_path)

        analysis_data = analyzer.analyze()

        structure = analysis_data.get("structure", {})
        tree_structure = filter_tree_structure(structure)
        metadata = analysis_data.get("metadata", {})

        project_name = github_url.rstrip("/").split("/")[-1].replace(".git", "")

        log("INFO", "Structure analysée.")

        commit_hash = metadata.get("last_commit_hash")

        if commit_hash:
            log("INFO", f"Commit analysé : {commit_hash}")
        else:
            log("WARNING", "Impossible de récupérer le commit hash.")

        # ==================================================
        # 3) Filtrage puis sélection des fichiers à analyser
        # ==================================================

        log("INFO", "Filtrage et sélection des fichiers à analyser...")

        raw_text_files = analyzer.list_text_files()
        text_files = _filter_source_files(raw_text_files)
        print("APRES FILTER:", len(text_files))

        ignored_count = len(raw_text_files) - len(text_files)
        if ignored_count:
            log(
                "INFO",
                f"{ignored_count} fichier(s) ignoré(s) "
                f"(générés, cachés, ou extension non pertinente)."
            )
        ai_files = _select_ai_candidate_files(text_files)
        important_files = _select_important_files(
            ai_files,
            max_files=int(os.environ.get("DOC_IMPORTANT_FILES_LIMIT", "35"))
        )
        print("APRES SELECTION:", len(important_files))
        for f in important_files:
            log(
                "INFO",
                f"AI FILE => {f['path']} "
                f"score={f.get('importance_score')}"
                )
        important_paths = {f["path"] for f in important_files}
        log(
            "INFO",
            f"{len(important_files)} fichier(s) prioritaire(s) "
            f"sur {len(text_files)} seront résumés par IA "
            f"(le reste utilise un résumé rapide local)."
        )

        ai_client = get_default_client()
        ai_start_time = time.monotonic()
        ai_calls_made = 0
        skipped_small_files = 0

        file_summaries = {}

        total_files = len(text_files)

        for index, file_info in enumerate(text_files, start=1):

            path = file_info["path"]

            try:
                content = GitAnalyzer.read_file(file_info["full_path"])

                if content is None:
                    continue

                line_count = _count_lines(content)

                if line_count < MIN_FILE_LINES:
                    skipped_small_files += 1
                    continue

                # NB : nommé `file_structure` (et non `structure`) pour
                # ne pas écraser la variable `structure` du projet
                # (l'arborescence complète) utilisée plus bas pour la
                # détection d'architecture et l'aperçu de structure.
                file_structure = _extract_code_structure(path, content)

                time_elapsed = time.monotonic() - ai_start_time

                use_ai = (
                    ENABLE_PER_FILE_AI_SUMMARIES
                    and path in important_paths
                    and ai_client.is_available()
                    and time_elapsed < AI_SUMMARY_TIME_BUDGET_SECONDS
                )

                if use_ai:
                    summary = ai_client.summarize_file(path, content)
                    ai_calls_made += 1
                else:
                    summary = heuristic_summary(path, content)

            except Exception:
                summary = "Résumé indisponible"
                file_structure = dict(_EMPTY_STRUCTURE)
                line_count = 0

            file_summaries[path] = {
                "summary": summary,
                "line_count": line_count,
                "structure": file_structure,
            }

            if index % 10 == 0 or index == total_files:
                log(
                    "INFO",
                    f"Résumés générés : {index}/{total_files} "
                    f"({ai_calls_made} via IA)"
                )

        if skipped_small_files:
            log(
                "INFO",
                f"{skipped_small_files} fichier(s) ignoré(s) "
                f"(moins de {MIN_FILE_LINES} lignes)."
            )

        if not ai_client.is_available():
            log(
                "WARNING",
                "Ollama indisponible ou trop lent : "
                "résumés heuristiques utilisés pour la suite."
            )

        log("INFO", "Détection architecture...")
        file_list = _build_files_list(file_summaries)
        architecture_result = detect_architecture(structure,files=file_list)

        architecture = architecture_result.get("type")

        ranking = architecture_result.get("full_ranking", [])

        architecture_score = None

        if ranking:
            architecture_score = ranking[0].get("raw_score")

        architecture_confidence = architecture_result.get(
            "confidence_pct",
            0
            )
        architecture_explanation = "\n".join(
            architecture_result.get("signals", [])
            )
        architecture_explanation = _build_architecture_explanation(
            architecture_result
        )

        # ==================================================
        # 4) Analyse globale du projet (IA)
        # ==================================================
        #
        # Remplace l'ancienne approche (concaténation des résumés
        # fichier par fichier) par une vraie analyse d'ensemble :
        # objectif, technologies, architecture, modules principaux,
        # flux de données, recommandations. C'est ce texte qui sert
        # de résumé IA global et d'intro du README.

        log("INFO", "Analyse globale du projet (IA)...")

        existing_readme_excerpt = _read_project_readme(repo_path)

        tech_stack = _infer_tech_stack(file_summaries)
        extra_techs, dependencies = _detect_technology_signals(repo_path)
        tech_stack = sorted(set(tech_stack) | set(extra_techs))
        database_techs = _detect_database_from_files(file_summaries)
        tech_stack = sorted(
            set(tech_stack)
            |set(extra_techs)
            |set(database_techs)
            )

        entry_points = _detect_entry_points(important_files)

        structure_overview = _build_structure_overview(structure)
        key_files_digest = _build_key_files_digest(
            file_summaries, important_paths
        )
        code_inventory = _build_code_inventory(
            file_summaries,
            important_paths
        )
        dependencies = _build_dependencies(
            repo_path,
            file_summaries
            )
        databases = analysis_data.get("databases", [])
        print("========== START OLLAMA PROJECT ANALYSIS ==========")

        ai_summary = ai_client.analyze_project(
            project_name=project_name,
            tech_stack=tech_stack,
            databases=databases,
            architecture_type=architecture,
            architecture_confidence=architecture_confidence,
            structure_overview=structure_overview,
            key_files_digest=key_files_digest,
            existing_readme_excerpt=existing_readme_excerpt,
            entry_points=entry_points,
            dependencies=dependencies,
            code_inventory=code_inventory,
        )
        print("========== END OLLAMA PROJECT ANALYSIS ==========")
        print(ai_summary[:500])

        readme_ai_content = ai_client.generate_readme_content(
            project_name=project_name,
            tech_stack=tech_stack,
            dependencies=dependencies,
            entry_points=entry_points,
            existing_readme_excerpt=existing_readme_excerpt,
            key_files_digest=key_files_digest,
            code_inventory=code_inventory,
            structure_overview=structure_overview,
            databases=databases,

        )
        print("========== README AI ==========")
        print(readme_ai_content[:500])
        documentation_ai_content = ai_client.generate_technical_documentation_content(
            project_name=project_name,
            tech_stack=tech_stack,
            databases=databases,
            architecture_type=architecture,
            architecture_confidence=architecture_confidence,
            structure_overview=structure_overview,
            key_files_digest=key_files_digest,
            entry_points=entry_points,
            dependencies=dependencies,
            code_inventory=code_inventory,
            existing_readme_excerpt=existing_readme_excerpt,
            repository_url=metadata.get("remotes", [None])[0],
            language=analysis_data.get("language"),
        )
        print("========== TECH DOC AI ==========")
        print(
            documentation_ai_content[:500]
            if documentation_ai_content
            else "TECH DOC EMPTY"
            )

        # ==================================================
        # 5) Documentation generation
        # ==================================================

        log("INFO", "Création documentation...")

        summaries_by_folder = {}

        for path, file_data in file_summaries.items():

            folder = os.path.dirname(path) or "."
            filename = os.path.basename(path)

            summaries_by_folder.setdefault(folder, {})[filename] = file_data

        folder_descriptions = {}
        folder_imports = {}

        for folder, files in summaries_by_folder.items():

            total_classes = sum(
                len(f["structure"].get("classes", [])) for f in files.values()
            )
            total_functions = sum(
                len(f["structure"].get("functions", [])) for f in files.values()
            )

            parts = [f"{len(files)} fichier(s)"]

            if total_classes:
                parts.append(f"{total_classes} classe(s)")

            if total_functions:
                parts.append(f"{total_functions} fonction(s)")

            folder_descriptions[folder] = ", ".join(parts) + "."

            imports = set()
            for f in files.values():
                imports.update(f["structure"].get("imports", []))
            folder_imports[folder] = imports

        output_dir = os.path.join("generated_docs", project_name)

        builder = DocBuilder(
            project_name, output_dir, min_lines_for_page=MIN_FILE_LINES
        )

        # Diagrammes (architecture en couches, flux de données,
        # dépendances entre modules, arborescence) : générés ici pour
        # pouvoir être embarqués directement dans le README, sans
        # dépendre d'une évolution des routes Flask / du frontend.
        tree_structure = filter_tree_structure(structure)
        mermaid_code = generate_mermaid_diagram(
            tree_structure,
            project_name
            )
        diagrams = {
            "architecture": generate_architecture_layers_diagram(
                structure,
                files=file_list,
                detection=architecture_result
                ),
                "dataflow": generate_dataflow_diagram(
                    structure,
                    files=file_list,
                    technologies=metadata.get("technologies", []),                    detection=architecture_result
                    ),
                "module_dependency": generate_module_dependency_diagram(folder_imports),
                "project_tree": mermaid_code,
                }

        # README
        code_overview = _build_code_overview(
            file_summaries
            )
        short_intro = f"Documentation automatique du projet {project_name}."

        readme_content = builder.build_readme(
            intro=short_intro,
            metadata=metadata,
            structure=structure,
            architecture_explanation=architecture_explanation,
            code_overview=code_overview,
            readme_body=readme_ai_content,
        )

        technical_documentation_content = documentation_ai_content or _build_technical_documentation_content(
            project_name=project_name,
            ai_summary=ai_summary,
            architecture_explanation=architecture_explanation,
            tech_stack=tech_stack,
            dependencies=dependencies,
            entry_points=entry_points,
            structure=structure,
            file_summaries=file_summaries,
        )
        documentation_content = builder.build_documentation_page(
            ai_summary=ai_summary,
            files=file_summaries,
            architecture=architecture_explanation,
            diagrams=diagrams,
            technical_content=technical_documentation_content,
        )
        print("README:", len(readme_content))
        print("DOC:", len(documentation_content))
        print("FILES:", len(file_summaries))
        print("TREE:", len(str(tree_structure)))
        print("AI:", len(ai_summary))


        # Page accueil MkDocs

        builder.build_index_page(intro=f"Documentation technique générée automatiquement pour {project_name}.", metadata=metadata)

        # Page architecture

        builder.build_architecture_page(architecture_result)

        # Page détection IA

        builder.build_detection_page(architecture_result, ai_summary)

        # ==================================================
        # Comparaison architecture
        # ==================================================

        log("INFO", "Génération page comparaison...")

        comparison_markdown = build_comparison_markdown(architecture)

        builder.build_comparison_page(comparison_markdown)

        # ==================================================
        # Diagramme Mermaid (page dédiée MkDocs)
        # ==================================================

        log("INFO", "Génération page diagramme...")
        builder.build_diagram_page(diagrams)

        # ==================================================
        # Pages modules (groupées par dossier)
        # ==================================================

        log("INFO", "Génération pages modules...")

        nav_entries = [
            ("Documentation technique", "documentation.md"),
            ("Architecture", "architecture.md"),
            ("Diagramme de structure", "diagramme.md"),
            ("Comparaison des architectures", "comparaison.md"),
            ("Détection & recommandations", "detection.md")
        ]

        for folder in sorted(summaries_by_folder.keys()):

            page = builder.build_folder_page(
                folder,
                folder_descriptions.get(folder, ""),
                summaries_by_folder[folder]
            )

            if page:
                nav_entries.append(
                    ("Racine" if folder == "." else folder, page)
                )

        # ==================================================
        # MkDocs configuration
        # ==================================================

        log("INFO", "Génération mkdocs.yml...")

        remotes = metadata.get("remotes", [])

        builder.build_mkdocs_yml(
            nav_entries,
            repo_url=remotes[0] if remotes else None
        )

        # ==================================================
        # Build HTML site
        # ==================================================

        log("INFO", "Génération du site HTML...")

        site_index_path = None

        try:

            subprocess.run(
                ["mkdocs", "build"],
                cwd=output_dir,
                check=True,
                capture_output=True,
                text=True,
                timeout=120
            )

            site_index_path = os.path.join(output_dir, "site", "index.html")

            log("INFO", f"Site HTML généré : {site_index_path}")

        except FileNotFoundError:
            log("ERROR", "MkDocs introuvable.")

        except subprocess.TimeoutExpired:
            log("ERROR", "Le build MkDocs a dépassé le délai imparti (120s).")

        except subprocess.CalledProcessError as e:
            log("ERROR", f"Erreur MkDocs build : {e.stderr}")

        # ==================================================
        # Final result
        # ==================================================

        file_path = os.path.join(output_dir, "README.md")

        log("INFO", "Documentation générée avec succès.")
        print("README size:", len(readme_content))
        print("DOCUMENTATION size:", len(documentation_content))
        print("README preview:", readme_content[:200])
        print("DOC preview:", documentation_content[:200])
        print("README != DOCUMENTATION:", readme_content != documentation_content)
        if readme_content == documentation_content:
            documentation_content = (
                documentation_content
                + "\n\n## Complément technique\n\nCette section détaille les modules principaux, le flux de données et les dépendances du projet pour éviter toute confusion avec le README de présentation."
            )
        print("README:", len(readme_content))
        print("DOC:", len(documentation_content))
        print("FILES:", len(file_summaries))
        print("TREE:", len(str(tree_structure)))
        print("AI:", len(ai_summary))
        # TEST MEMORY BEFORE RETURN
        result_test = {
            "readme_content": readme_ai_content,
            "documentation_content": documentation_ai_content,
            "structure": structure,
            "repository_tree": tree_structure,
            "files": _build_files_list(file_summaries),
            "diagrams": diagrams,
            }
        import json
        print("========== RETURN SIZE TEST ==========")
        print(
            "JSON SIZE MB:",
            len(json.dumps(result_test)) / 1024 / 1024
            )
        print(
            "FILES JSON SIZE MB:",
            len(json.dumps(result_test["files"])) / 1024 / 1024
            )
        print(
            "TREE JSON SIZE MB:",
            len(json.dumps(result_test["repository_tree"])) / 1024 / 1024
            )
        print(
            "DOC SIZE MB:",
            len(result_test["documentation_content"]) / 1024 / 1024
            )
        print("======================================")


        return {
            "readme_content": readme_content,
            "documentation_content": documentation_content,
            "documentation_path": os.path.join(
                output_dir,
                "docs"
                ),
            "file_path": file_path,
            "site_path": site_index_path,
            "commit_hash": commit_hash,
            "architecture": architecture,
            "architecture_score": architecture_score,
            "architecture_confidence": architecture_confidence,
            "architecture_explanation": architecture_explanation,
            "ai_summary": ai_summary,
            "structure": structure,
            "repository_tree": tree_structure,
            "files": _build_files_list(file_summaries),
            "files_count": len(important_files),
            "directories_count": _count_directories(structure),
            "technologies": tech_stack,
            "entry_points": entry_points,
            "dependencies": dependencies,
            "diagrams": diagrams,
            "metadata": metadata
        }

    except Exception as e:

        log("ERROR", str(e))

        raise DocumentationPipelineError(str(e))